from setuptools import setup

setup(name='qm2_human_rarity_prj',
      version='0.1.0',
      packages=['qm2_human_rarity'],
      )
